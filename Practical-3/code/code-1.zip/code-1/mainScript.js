const myMath = require('./myMathOperations');

const number1 = 10;
const number2 = 5;

console.log(`Sum: ${myMath.sum(number1, number2)}`);
console.log(`Difference: ${myMath.difference(number1, number2)}`);
console.log(`Product: ${myMath.product(number1, number2)}`);
console.log(`Quotient: ${myMath.quotient(number1, number2)}`);