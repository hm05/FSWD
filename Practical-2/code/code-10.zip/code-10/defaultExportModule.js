// Default function to calculate the square of a number
export default function square(number) {
    return number * number;
  }
  