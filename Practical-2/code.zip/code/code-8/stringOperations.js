// stringOperations.js

// Function to concatenate two strings
exports.concatenation = (str1, str2) => str1 + str2;

// Function to convert a string to uppercase
exports.uppercase = (str) => str.toUpperCase();

// Function to convert a string to lowercase
exports.lowercase = (str) => str.toLowerCase();
